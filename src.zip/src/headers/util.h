#pragma once

#define SQUARE(x) ((x) * (x))
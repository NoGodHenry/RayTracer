#pragma once

typedef struct {
	char* buffer;
	int size;
	int index;
} FrameBuffer;

void write(FrameBuffer*, char);

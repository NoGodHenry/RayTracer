#pragma once

#include "color.h"
#include "object.h"

Color fragmentShader(int, int, Vector3f, Object*);
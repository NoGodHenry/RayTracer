#pragma once

#include "framebuffer.h"

extern int width, height;

void render(FrameBuffer*);

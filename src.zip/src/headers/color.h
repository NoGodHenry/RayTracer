#pragma once

typedef struct {
    int r, g, b;
} Color; 
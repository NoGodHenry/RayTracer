#pragma once

#include "object.h"

void physics_handle(Object*);
void physics_update();
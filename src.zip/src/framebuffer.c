#include <stdlib.h>

#include "headers/framebuffer.h"

void write(FrameBuffer* fbo, char c){
	if(fbo->index >= fbo->size)
		exit(1);

	fbo->buffer[fbo->index] = c;
	fbo->index++;
}

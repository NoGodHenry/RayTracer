#include <stdlib.h>
#include <stdio.h>
#include <strings.h>

#include "headers/object.h"
#include "headers/util.h"

Object* objects;
int objectCount = 0;

    
Object* spawnObject(int x, int y, int z, int radius){
    objectCount++;

    objects = objectCount ? realloc(objects, objectCount * sizeof(Object)) :
                malloc(sizeof(Object));

    Object* obj = &objects[objectCount - 1];
    obj->visible = true;
    obj->position.x = x;
    obj->position.y = y;
    obj->position.z = z;

    obj->velocity.x = obj->velocity.y = obj->velocity.z = 0;

    obj->radius = radius;
    obj->radiusSq = SQUARE(radius);
    
    return obj;
}
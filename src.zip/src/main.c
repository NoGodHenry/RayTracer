#include <stdio.h>
#include <stdlib.h>

#include "headers/raycaster.h"
#include "headers/framebuffer.h"
#include "headers/renderer.h"
#include "headers/object.h"
#include "headers/physics.h"

int main(int argc, char** argv) {
    if (argc != 3) {
        printf("%s width height\n", argv[0]);
        return 1;
    }

    width = atoi(argv[1]);
    height = atoi(argv[2]);

    spawnObject(0,0, -10, 2)->velocity.y = .2;
    
    int pixels = height * (width + 2); 

    FrameBuffer fbo = {
        .buffer = malloc(pixels + 1),
        .size = pixels,
        .index = 0
    };

    bzero(fbo.buffer, pixels + 1);

    while(1){ 
        render(&fbo);
        physics_update();
        printf("\033[2J");
        printf("%s\n", fbo.buffer);
        fbo.index = 0;
        usleep(100000);
    }
}

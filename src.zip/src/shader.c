#include "headers/shader.h"

Color fragmentShader(int screenX, int screenY, Vector3f interseciton, Object* obj){
    Color fragColor = {
        .r = 0,
        .g = 0,
        .b = 0
    };

    obj->position
}
#include <math.h>

#include "headers/physics.h"
#include "headers/object.h"

void physics_update() {
    for(int i = 0; i < objectCount; i++)
        physics_handle(&objects[i]);
}

void physics_handle(Object* obj) {
    if(!obj->visible)
        return;

    obj->position.x += obj->velocity.x;
    obj->position.y += obj->velocity.y;
    

}
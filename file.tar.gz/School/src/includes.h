#pragma once

typedef char BOOL;

#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))

#define SQUARE(x) ((x) * (x))

typedef struct {
	float x, y;
} Vector2f;

typedef struct {
	BOOL present;
	float x, y;
	float radiusSquared;
	float radius;
	Vector2f velocity;
} Point;

typedef struct {
  int r, g, b;
} Color;

Point* points;
int pointSize;

int width, height;
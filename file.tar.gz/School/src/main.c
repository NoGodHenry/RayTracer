#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <stdbool.h>
#include <unistd.h>
#include <fcntl.h>
#include <math.h>

#include "includes.h"

void sky_fragmentShader(int x, int y, Color* c){
    c->r = ((float) y)/height*200;
    c->g = 153;
    c->b = 210;
}


void point_fragmentShader(int x, int y, Point* p, Color* c){
    //Color backGroundColor;
    //sky_fragmentShader(x, y, &backGroundColor);

    double dist = sqrt((SQUARE(p->x - x) + SQUARE(p->y - y)));
    c->r = 255;
    c->g = 0;
    c->b = 100;
}

void render(int x, int y){
    Color color;
    for(int i = 0; i < pointSize; i++){
        Point* p = &points[i];
        if(p->present == 0)
            continue;

        if((SQUARE(p->x - x) + SQUARE(p->y - y)) <= p->radiusSquared){
            point_fragmentShader(x, y, p, &color);
            printf("\033[48;2;%d;%d;%dm ", color.r, color.g, color.b);
            return;
        }
    }
    sky_fragmentShader(x, y, &color);
    printf("\033[48;2;%d;%d;%dm ", color.r, color.g, color.b);
}

void drawBoard() {
    for(int y = 0; y < height; y++){
        for(int x = 0; x < width; x++){
            render(x, height - y);
        }
        printf("\n");
    }
}

void algorithm() {
    for(int i = 0; i < pointSize; i++){
        Point* p = &points[i];
        if(p->present == 0)
            continue;
   
        p->velocity.y -= 0.8;
            
        p->velocity.x *= 0.98;
      //  p->velocity.y *= 0.99;
	 
        if(p->y - p->radius <= 0){
            p->velocity.y = -p->velocity.y/2;
            p->y = p->radius;
        }

        if(p->x - p->radius <= 0){
            p->velocity.x = -p->velocity.x/2;
            p->x = p->radius;
        }
        if(p->x + p->radius >= width){
            p->velocity.x = -p->velocity.x/2;
            p->x = width - p->radius;
        }

        p->x += p->velocity.x;
        p->y += p->velocity.y;

        //Collisions
        for(int j = 0; j < pointSize; j++){
            Point* p2 = &points[j];
            if(p2->present == 0 || p2 == p)
                continue;
            
            float DxSq = SQUARE(p->x - p2->x);
            float DySq = SQUARE(p->y - p2->y);
            
            if(DySq + DxSq < MIN(p->radiusSquared, p2->radiusSquared)){
                double angle = atan2(p2->y - p->y, p2->x - p->x);
                float distanceToMove = p->radius + p2->radius - sqrt(DySq + DxSq);
        
                p->x -= cos(angle) * distanceToMove;
                p->y -= sin(angle) * distanceToMove;

                p->velocity.x = -p->velocity.x/2;
                p->velocity.y = -p->velocity.y/2;
            }
        }
        
    }

}

Point* spawnBall(int x, int y, int radius){
    pointSize++;
    points = realloc(points, pointSize * sizeof(Point));
    points[pointSize-1].present = true;
    points[pointSize-1].x = x;
    points[pointSize-1].y = y;
    points[pointSize-1].radiusSquared = radius * radius;
    points[pointSize-1].radius = radius;
    return &points[pointSize-1];
}


int main(int argc, char** argv) {
    char input;

    if(argc < 3){
        printf("./%s W H", argv[0]);
        return 1;
    }

    fcntl(0, F_SETFL, fcntl(0, F_GETFL) | O_NONBLOCK);

    srand(time(NULL));

    width = atoi(argv[1]); 
    height = atoi(argv[2]); 

    printf("\033[2J");    
    pointSize = 0;
    points = calloc(pointSize, sizeof(Point));
    spawnBall(10,30,5)->velocity.x = 8;
    spawnBall(50,30,5)->velocity.x = -8;

    while(1){
        printf("\033[2J");
        drawBoard(width, height);
        algorithm(width, height);
        if(read(0, &input, sizeof(char)) > 0){
            spawnBall(50,30,5)->velocity.x = -8;
        }
        usleep(100000);
    }

}
